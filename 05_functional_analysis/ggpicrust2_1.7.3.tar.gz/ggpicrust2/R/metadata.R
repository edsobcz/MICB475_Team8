#' Metadata for ggpicrust2 Demonstration
#'
#' This is a demonstration dataset from the ggpicrust2 package. It provides the metadata
#' required for the demonstration functions in the package. The dataset includes
#' environmental information for each sample.
#'
#' @format A tibble with each row representing metadata for a sample.
#' \describe{
#'   \item{Sample1}{Metadata for Sample1, including Environment}
#'   \item{Sample2}{Metadata for Sample2, including Environment}
#'   \item{...}{...}
#' }
#' @source ggpicrust2 package demonstration.
#' @references Douglas GM, Maffei VJ, Zaneveld J, Yurgel SN, Brown JR, Taylor CM, Huttenhower C, Langille MGI. PICRUSt2 for prediction of metagenome functions. Nat Biotechnol. 2020.
"metadata"
